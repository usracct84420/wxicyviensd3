jQuery(document).ready(function(){
  jQuery('span[data-d3-rune-tooltip]').mouseenter(function() {
    var rune = jQuery(this).data('d3-rune-tooltip');
    var rune_id = rune + "-wrapper";
    if (jQuery("#" + rune_id).length == 0) {
      wrapper = jQuery(document.createElement('div')).attr("id", rune_id).attr("class", "d3-tooltip-wrapper")
      wrapper.css("display", "none");
      wrapper.css("position", "fixed");
      inner_wrapper = jQuery(document.createElement('div')).attr("class", "d3-tooltip-wrapper-inner");
      inner_wrapper.appendTo(wrapper);
      wrapper.appendTo(jQuery("body"));
      jQuery("#" + rune_id + " .d3-tooltip-wrapper-inner").load("/d3/rune-tooltips/" + rune);
    }
    tooltip_wrapper = jQuery("#" + rune_id);
    // Coordinates
    offset_rune = jQuery(this).offset();
    offset_top = offset_rune.top - jQuery(window).scrollTop(); // top of window to top of element
    offset_bottom = jQuery(window).height() - (offset_top + jQuery(this).outerHeight()); // bottom of window to bottom of element
    offset_left = offset_rune.left - jQuery(window).scrollLeft(); // left of window to left of element
    offset_right = jQuery(window).width() - (offset_left + jQuery(this).outerWidth()); //  right of window to right of element
    if (offset_top >= offset_bottom) {
      tooltip_wrapper.css("bottom", (jQuery(window).height() - offset_top) + "px"); 
      tooltip_wrapper.css("top", "auto");
    } else {
      tooltip_wrapper.css("top", (jQuery(window).height() - offset_bottom) + "px");
      tooltip_wrapper.css("bottom", "auto");
    }
    if (offset_left >= offset_right) {
      tooltip_wrapper.css("right", (jQuery(window).width() - offset_left) + "px"); 
      tooltip_wrapper.css("left", "auto");
    } else {
      tooltip_wrapper.css("left", (jQuery(window).width() - offset_right) + "px"); 
      tooltip_wrapper.css("right", "auto");
    }
    jQuery("#" + rune_id).show();
    }).mouseleave(function() {
      var rune = jQuery(this).data('d3-rune-tooltip');
      var rune_id = rune + "-wrapper";
      jQuery("#" + rune_id).hide();
    });
});

