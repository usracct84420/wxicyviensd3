jQuery.noConflict();

// To prevent the Complitly plugin in Chrome from sending millions of /undefined requests to our servers. Who installs that crap, seriously?
window.suggestmeyes_loaded = true;

jQuery(document).ready(function(){

  // GOOGLE ANALYTICS

  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-23106911-1', 'icy-veins.com');
  ga('send', 'pageview');

  // Check if ads are blocked
  generate_728_90 = function(id) {
    jQuery('<img src="http://static.icy-veins.com/images/iv/warning.png" />' +
        '<p>It appears that you may be blocking the ads, and we are fine with it (read more <a href="http://www.icy-veins.com/forums/topic/2781-our-stance-on-ads-and-ad-blockers/">here</a>). That said, it would really be awesome if you decided to whitelist our website or make a <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=CG2GSWAELN3NL">donation</a> :) You can also send us <a href="bitcoin:1DEkropiHPWBmfJxogFaXQscfzhmdpTti4?label=Icy+Veins+Donation">Bitcoins</a> (1DEkropiHPWBmfJxogFaXQscfzhmdpTti4)!</p>'
        ).appendTo("#" + id + " div");
    jQuery("#" + id).show();
  };
  // top 728x90
  if (jQuery("#top_ad").css("display") == "none") {
    jQuery("div#right").first().css("margin-top", "0px");
    jQuery(".rectangle").first().css("min-height", "auto");
    if (Math.random() < 0.1) {
      generate_728_90("top_plea_container");
    }
  }

  // Links / Anchors
  jQuery("a").on("click", function() {
    href = this.href;
    var url = document.createElement('a');
    url.href = "http://www.example.com/some/path?name=value#anchor";
    var protocol = url.protocol;
    var hash = url.hash;

    if (href == undefined) {
      return;
    } else if ((/^#/.test(href)) ||
        (this.hostname == window.location.hostname &&
         this.pathname == window.location.pathname &&
         this.search == window.location.search &&
         this.hash != "")) {
      // Anchor on current page or another page on Icy Veins. 
      // If on desktop, then account for the minified header when following the anchor
      if (document.documentElement.clientWidth >= 1070 || icy_veins_force_desktop) {
        window.scroll(0, jQuery(this.hash).offset().top - 90);
        return false;
      } else {
        return;
      }
    } else if (window.location.hostname != this.hostname) { // Link to another domain
      if (jQuery(this).attr("onclick")) { // click already handled
        return;
      } else {
        window.open(href);
        return false;
      }
    } else { // Link to another page. If it has an anchor, this is handled directly when landing on the page.
      return;
    }
  });
  if (window.location && window.location.hash != "") {
    setTimeout(function() {
      window.scrollTo(0, jQuery(window.location.hash).offset().top - 90);
    }, 1);
  }

  jQuery(".local_date").each(function() {
    current_time = new Date();
    date_to_change = new Date(jQuery(this).attr("data-time") * 1000);
    jQuery(this).find(".local_date_hour").text(("0" + date_to_change.getHours()).slice(-2) + ":" +
        ("0" + date_to_change.getMinutes()).slice(-2));
    if (current_time.getFullYear() == date_to_change.getFullYear() &&
        current_time.getMonth() == date_to_change.getMonth() &&
        current_time.getDate() == date_to_change.getDate()) {
      jQuery(this).find(".local_date_date").text("Today");
    } else {
      yesterday = new Date(current_time - 86400000);
      if (yesterday.getFullYear() == date_to_change.getFullYear() &&
          yesterday.getMonth() == date_to_change.getMonth() &&
          yesterday.getDate() == date_to_change.getDate()) {
        jQuery(this).find(".local_date_date").text("Yesterday");
      } else {
        month_short_names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        jQuery(this).find(".local_date_date").text(month_short_names[date_to_change.getMonth()] + " " +
            ("0" + date_to_change.getDate()).slice(-2) + ", " + date_to_change.getFullYear());
      }
    }
  });

  check_top_leaderboard = function() {
    if (jQuery("#top_leaderboard_container").width() > 1070) {
      jQuery("#top_leaderboard_container").css("margin-left", "-" + (jQuery("#top_leaderboard_container").width() - 1070) / 2 + "px");
    } else {
      if (jQuery("#top_leaderboard_container>div.leaderboard").width() > 1070) {
        jQuery("#top_leaderboard_container>div.leaderboard").css("margin-left", "-" + (jQuery("#top_leaderboard_container>div.leaderboard").width() - 1070) / 2 + "px");
      } else {
        setTimeout(check_top_leaderboard, 500);
      }
    }
  }
  check_top_leaderboard();

  if (document.getElementById('adsense') != undefined) {
    if (jQuery("#adsense").css("display") != "none") {
      if (jQuery("#adsense").height() == 0) {
        ga('send', 'event', 'Adblock', 'Blocked', "true");
      } else {
        if (icy_veins_b) {
          ga('send', 'event', 'Adblock', 'Blocked', "true");
        } else {
          ga('send', 'event', 'Adblock', 'Unblocked', "false");
        }
      }
    } else {
      ga('send', 'event', 'Adblock', 'Blocked', "true");
    }
  } else {
    ga('send', 'event', 'Adblock', 'Blocked', "true");
  }


});

