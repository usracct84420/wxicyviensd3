// Highslide configuration
hs.graphicsDir = 'http://static.icy-veins.com/images/highslide/';
hs.outlineStartOffset = 3;
hs.outlineType = 'rounded-white';
hs.showCredits = false;

function transmogrification_hover_enter_function() {
  thumbnails = jQuery(this).parent().children();
  if (typeof thumbnails_source_length == "undefined") {
    if (thumbnails.length != 0) {
      thumbnails_source_length = - thumbnails.first().offset().left + 135 + 
      Math.max.apply(Math, thumbnails.map(function() {
        return jQuery(this).offset().left;
      }));
    }
  }
  thumbnails_el = thumbnails.first();
  source_el =  jQuery(this).children(".transmogrification_thumbnail_source").first();
  top_position = jQuery(this).offset().top - thumbnails_el.offset().top + 135;
  source_el.css("width", thumbnails_source_length);
  source_el.css("top", top_position + "px");
  source_el.css("left", "0px");
  source_el.show();
}
function transmogrification_hover_exit_function() {
  source_el = jQuery(this).children(".transmogrification_thumbnail_source").first();
  source_el.hide();
}

jQuery(document).ready(function(){

  // TABLE OF CONTENT
  jQuery("ul.toc>li.toc_expandable>span, ul.toc>li.toc_expanded>span").click(function () {
    if (jQuery(this).parent().hasClass("toc_expanded")) {
      jQuery(this).parent().addClass("toc_expandable");
      jQuery(this).parent().removeClass("toc_expanded");
      jQuery(this).html("+");
      jQuery(this).parent().children().last().hide();
    } else {
      jQuery(this).parent().addClass("toc_expanded");
      jQuery(this).parent().removeClass("toc_expandable");
      jQuery(this).html("&#215;");
      jQuery(this).parent().children().last().show();
    }
  });

  // HIDE SECTIONS
  // Hide hidden sections with a corresponding title tag
  jQuery(".hidden_section_with_title").hide();
  // Find the first preceding title tag
  jQuery(".hidden_section_with_title").each(function(){
    var first_h = jQuery(this).prevAll("h2,h3,h4").first();
    first_h.append("<span class=\"hidden_section_with_title_display_button hidden_section_with_title_button\">+ display section</span>");
    first_h.append("<span class=\"hidden_section_with_title_hide_button hidden_section_with_title_button\" style=\"display:none;\">- hide section</span>");
  });
  jQuery(".hidden_section_with_title_display_button").click(function() {
    jQuery(this).next().show();
    jQuery(this).hide();
    jQuery(this).parent().nextAll(".hidden_section_with_title:first").show('slow');
  });
  jQuery(".hidden_section_with_title_hide_button").click(function() {
    jQuery(this).parent().nextAll(".hidden_section_with_title:first").hide('slow');
    jQuery(this).hide();
    jQuery(this).prev().show();
  });

  // TABLE PARTS TO HIDE
  jQuery(".table_hide_anchor").nextUntil(".table_hide_anchor").hide();
  jQuery(".table_hide_anchor").each(function() {
    jQuery(this).children().append("<span class=\"table_hide_anchor_display_button\" style=\"margin-left:20px; color:#ffe366;cursor:pointer; font-size:14px; font-weight:normal;\">+ display</span>");
    jQuery(this).children().append("<span class=\"table_hide_anchor_hide_button\" style=\"display:none; margin-left:20px; color:#ffe366;cursor:pointer; font-size:14px; font-weight:normal;\">- hide</span>");
  });
  jQuery(".table_hide_anchor_display_button").click(function() {
    jQuery(this).next().show();
    jQuery(this).hide();
    jQuery(this).parent().parent().nextUntil(".table_hide_anchor").show();
  });
  jQuery(".table_hide_anchor_hide_button").click(function() {
    jQuery(this).parent().parent().nextUntil(".table_hide_anchor").hide();
    jQuery(this).hide();
    jQuery(this).prev().show();
  });

  // Top Button - disable for the forums and root
  if (window.location.pathname.match(/forums/) == null && window.location.pathname.match(/\/$/) == null) {
    var page_top_container = jQuery('#page_top_container');
    var page_top = jQuery('#page_top');
    var center_bottom = jQuery("#center").offset().top + jQuery("#center").height();
    var right_bottom = jQuery("#right").offset().top + jQuery("#right").height();
    if (center_bottom > right_bottom) {
      jQuery(window).scroll(function (event) {
        var bottom_container = page_top_container.offset().top + 37 + 20; // page_top_container + height + margin
        var bottom = page_top.offset().top + 37; // page_top + height
        var window_bottom = jQuery(this).scrollTop() + jQuery(window).height();
        center_bottom = jQuery("#center").offset().top + jQuery("#center").height();
        //alert("bottom: " + bottom + " / window_bottom: " + window_bottom + " / center_bottom: " + center_bottom);
        // In initial position
        if (page_top.css('position') == "static" && (window_bottom > bottom_container)) {
          page_top.css("position", "fixed");
          page_top.css("bottom", "20px");
          page_top.css("display", "block");
        } else if (page_top.css('position') == 'fixed' && !(window_bottom > bottom_container)) {
          page_top.css("display", "none");
          page_top.css("position", "static");
          page_top.css("bottom", "auto");
        } else if (page_top.css('position') == 'fixed' && window_bottom - 20 > center_bottom) {
          page_top.css("position", "absolute");
          page_top.css("bottom", "-" + (center_bottom - bottom + 37 + 20) + "px");
        } else if (page_top.css('position') == 'absolute' && !(window_bottom - 20 > center_bottom)) {
          page_top.css("position", "fixed");
          page_top.css("bottom", "20px");
        }
      });
    }
  }

  jQuery(".transmogrification_thumbnail").hover(transmogrification_hover_enter_function,
      transmogrification_hover_exit_function);

});
