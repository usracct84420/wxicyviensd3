## Copyright (c) 2016, Joshua Dagenhart
## All rights reserved.
## 
## Redistribution and use in source and binary forms, with or without
## modification, are permitted provided that the following conditions are met:
## 
## 1. Redistributions of source code must retain the above copyright notice, this
##    list of conditions and the following disclaimer.
## 2. Redistributions in binary form must reproduce the above copyright notice,
##    this list of conditions and the following disclaimer in the documentation
##    and/or other materials provided with the distribution.
## 
## THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
## ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
## WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
## DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
## ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
## (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
## LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
## ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
## (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
## 
## The views and conclusions contained in the software and documentation are those
## of the authors and should not be interpreted as representing official policies,
## either expressed or implied, of the FreeBSD Project.

import  wx

#if wx.Platform == '__WXMSW__':
import wx.lib.iewin as iewin

#----------------------------------------------------------------------

class URLPagePanel(wx.Panel):
    def __init__(self, parent, url=None):
        wx.Panel.__init__(
            self, parent, -1,
            style=wx.TAB_TRAVERSAL|wx.CLIP_CHILDREN|wx.FULL_REPAINT_ON_RESIZE
            )
            
        sizer = wx.BoxSizer(wx.VERTICAL)

        self.ie = iewin.IEHtmlWindow(self)


        sizer.Add(self.ie, 1, wx.EXPAND)
        if url is not None:
            self.ie.LoadUrl(url)

        self.SetSizer(sizer)
        # Since this is a wx.Window we have to call Layout ourselves
        self.Bind(wx.EVT_SIZE, self.OnSize)

        self.ie.SetFocus()

        ## Hook up the event handlers for the IE window.  Using
        ## AddEventSink is how we tell the COM system to look in this
        ## object for method names matching the COM Event names.  They
        ## are automatically looked for in the ActiveXCtrl class, (so
        ## deriving a new class from IEHtmlWindow would also have been
        ## a good appraoch) and now they will be looked for here too.
        self.ie.AddEventSink(self)

        #self.ZoomFactor(10)


    def OnSize(self, evt):
        self.Layout()
        #self.ie.SetScrollPos(wx.VERTICAL, 1000, False)
        
    def TitleChange(self, this, Text):
        self.GetTopLevelParent().SetTitle(Text)

    def StatusTextChange(self, this, Text):
        self.GetTopLevelParent().SetStatusText(Text)
    #def DownloadComplete(self, this):
    #    print this
    #    print 'ie', self.ie.GetScrollRange(wx.HORIZONTAL)
    #    print 'self', self.GetScrollRange(wx.HORIZONTAL)
    #    self.ie.SetScrollbar(wx.VERTICAL, 0, 16, 50)
    #def ZoomFactor(self, factor):
    #    #from win32com.client import VARIANT
    #    #import pythoncom
    #    #v = VARIANT(pythoncom.VT_I4, factor)
    #    self.ie.ctrl.ExecWB( iewin.SHDocVw.OLECMDID_OPTICAL_ZOOM, 0, factor)
    # def GetText(self, asHTML=True):
    #     """
    #     Returns the contents of the the html document as either html or plain text.
    #     """
    #     if self.ctrl.Document is None:
    #         return ""
    #     if not hasattr(sys, 'frozen'): cc.GetModule('mshtml.tlb')
    #     from comtypes.gen import MSHTML
    #     doc = self.ctrl.Document.QueryInterface(MSHTML.IHTMLDocument2)
    #     if not asHTML:
    #         # if just fetching the text then get it from the body property
    #         return doc.body.innerText
    #     
    #     # otherwise look in the all property
    #     for idx in range(doc.all.length):
    #         # the first item with content should be the <html> tag and all its
    #         # children.
    #         item = doc.all.item(idx)
    #         if item is None:
    #             continue
    #         return item.outerHTML
    #     return ""

"""
    def OnHomeButton(self, event):
        self.ie.GoHome()    ## ET Phone Home!

    def OnPrevPageButton(self, event):
        self.ie.GoBack()

    def OnNextPageButton(self, event):
        self.ie.GoForward()
    def OnStopButton(self, evt):
        self.ie.Stop()

    def OnSearchPageButton(self, evt):
        self.ie.GoSearch()

    def OnRefreshPageButton(self, evt):
        self.ie.Refresh(iewin.REFRESH_COMPLETELY)
"""


        

class URLPagePanelFrame(wx.Frame):
    def __init__(self, parent, size, url):

        wx.Frame.__init__(self, parent, -1, "", pos=wx.DefaultPosition, size=size, style=wx.DEFAULT_FRAME_STYLE)
        self.CreateStatusBar()
        self.tp = URLPagePanel(self, url)

        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.tp, 1, wx.ALL|wx.EXPAND, 5)
        self.SetSizer(sizer)

        self.Bind(wx.EVT_CLOSE, self.OnCloseWindow, self)
        self.CenterOnScreen(True)
        self.Show(True)
        
            
        
    def OnCloseWindow(self, evt):
        self.Destroy()
        evt.Skip()
        

class MyApp(wx.App):
    def OnInit(self):
        f = URLPagePanelFrame(None, (800, 800), 'http://us.battle.net/d3/en/item/accursed-visage')
        self.SetTopWindow(f)
        return True
        
    
REDIRECT, OUT = (True, 'errors.txt')
def runapp():
    app = MyApp(useBestVisual=True) if not REDIRECT else MyApp(REDIRECT, OUT, True)
    return app
    
if __name__ == '__main__':
    app = runapp()
    app.MainLoop()
    
