## Copyright (c) 2016, Joshua Dagenhart
## All rights reserved.
## 
## Redistribution and use in source and binary forms, with or without
## modification, are permitted provided that the following conditions are met:
## 
## 1. Redistributions of source code must retain the above copyright notice, this
##    list of conditions and the following disclaimer.
## 2. Redistributions in binary form must reproduce the above copyright notice,
##    this list of conditions and the following disclaimer in the documentation
##    and/or other materials provided with the distribution.
## 
## THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
## ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
## WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
## DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
## ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
## (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
## LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
## ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
## (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
## 
## The views and conclusions contained in the software and documentation are those
## of the authors and should not be interpreted as representing official policies,
## either expressed or implied, of the FreeBSD Project.
"""
Specials - class specfic sets (green colored)
Legendary - non-class specfic sets (orange colored)
@ - B - Barbarian    (dark orange)
# - C - Crusader     (light grey)
$ - D - Demon Hunter (dark red)
! - M - Monk         (light yellow)
% - W - Witch Doctor (dark blue)
* - Z - Wizard       (dark purple)
Application:
        
    
    Items is a list with columns "img, name (colored letters), applied class images (class resource color)"
        CheckBoxes for each class as well as a "only" checkbox for all, sets, and legendary will filter respectivly
        
"""
 # "C:\Program Files\Mozilla Firefox\firefox.exe" "http://www.icy-veins.com/d3/legendary-item-salvage-guide" -save-to-folder "D:\dev\py\work\d3items\New folder" 
import os, sys
# HERE = os.path.dirname(os.path.abspath(__file__))
try:
   if sys.frozen or sys.importers:
      HERE = os.path.dirname(sys.executable)
except AttributeError:
   HERE = os.path.split(os.path.abspath(__file__))[0]
   
BUILDS = 'All Builds' # delete the folder to allow a rebuild of the pages or delete the html build files

# the following 2 functions are only used in start_tag(tag, attrs)
icyfolder = lambda ashtml=False: 'Diablo 3 Legendary Item Salvage Guide - Icy Veins_files/' if not ashtml else 'Diablo%203%20Legendary%20Item%20Salvage%20Guide%20-%20Icy%20Veins_files/'
# the first is for the value of "src" in "class Item" and the 2nd function is so start_tag is neat and clean
def fetch(name, attrs): # handy man gopher
    v = None
    for a in attrs: # i thought it was a dict
        if name in a:
            v = a[1] # but its a (attribute_name, attribute_value)
            break
            # attrs of handle functions are lists, not dicts!
    return v
def start_tag(tag, attrs):
# PRESUMES the page keeps to the table structure
# and the img and a tags contain targets
    # (alt (name), src (png))
    #         or
    # cls (leg/set), href (battlenet)
    if tag == "img":
        alt = fetch('alt', attrs) ## Aether Walker
        src = fetch('src', attrs) ## *.png
        #src = src.replace(icyfolder(True), 'http://static.icy-veins.com/images/d3/')
        src = src.replace(icyfolder(True), icyfolder())
        return alt, os.path.join(HERE, src)
    elif tag == 'a':
        cls = fetch('class', attrs) ## d3_legendary | d3_set
        href = fetch('href', attrs) ## http://us.battle.net/d3/en/item/...
        return cls, href
    else:
        return None, None
    
class Info:
    def __init__(self, tmp):
        self.alt = tmp[0]## Aether Walker
        self.src = tmp[1]## *.png
        self.cls = tmp[2]## d3_legendary | d3_set
        self.ref = tmp[3]## http://us.battle.net/d3/en/item/...
        self.builds = []
        
    def islegendary(self):
        yup = False
        if self.cls == 'd3_legendary':
            yup = True
        return yup
        
    def isclass(self, cls):
        yup = False
        for build in self.builds:
            if cls in build.split():
                yup = True
                break
        return yup
        
        
    def __str__(self):
        return '{}, {}, {}'.format(self.alt, self.cls, len(self.builds))

from HTMLParser import HTMLParser


class MyHTMLParser(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self)
        self.items = []
        self.tmp = []
        
    def handle_starttag(self, tag, attrs):
        ff, fff = start_tag(tag, attrs)
        if None not in [ff, fff]:
            self.tmp += [ff]
            self.tmp += [fff]
    def handle_startendtag(self, tag, attrs):
        ff, fff = start_tag(tag, attrs)
        if None not in [ff, fff]:
            self.tmp += [ff]
            self.tmp += [fff]
        
    def handle_endtag(self, tag):
        if tag == 'span':
            if len(self.tmp) == 4:
                self.items += [Info(self.tmp)]
                self.tmp = []


class Build:
    def __init__(self, link, text):
        self.link = link
        self.title = text
        remains = text.find('(')
        self.bis = False
        self.alt = False
        self.cube = False
        self.outdated = False
        self.remains = ""
        if remains > -1:
            self.title = text[:remains].strip()
            remains = text[remains:]
            if remains.find('BiS') > -1:
                self.bis = True
            if remains.find('Alt') > -1:
                self.alt = True
            if remains.find('Cube') > -1:
                self.cube = True
            if remains.find('outdated') > -1:
                self.outdated = True
                remains = remains.replace('<span style="font-size:10px; color:red;">outdated</span>', 'Outdated')
            self.remains = remains.strip()
    def split(self): # split the class of the build from the title
        name = self.title
        cls = None
        for c in CLASSES:
            if name.find(c) > -1:
                cls = c
                name = name.replace(c, '').strip()
                break
        return cls, name
    def linkname(self):
        return os.path.splitext(os.path.split(self.link)[1])[0]
    def __str__(self):
        split = '{}, {}'.format(*self.split())
        ls = []
        for name, yup in zip(['BiS', 'Alt', 'Cube', 'Outdated'], [self.bis, self.alt, self.cube, self.outdated]):
            if yup:
                ls += [name]
        return '{} ({})'.format(split, ' + '.join(ls))



import urllib
BULL = [
    'xmlns:fb="http://www.facebook.com/2008/fbml"', 
    'xmlns:og="http://opengraphprotocol.org/schema/"', 
    '<script type="text/javascript" src="http://aka-cdn-ns.adtechus.com/dt/common/DAC.js"></script>',
    '<script type="text/javascript" src="http://static.icy-veins.com/javascript/adsense-9084fe904043ca82966a4bbc61e27b6e.js"></script>',
    '<link href="http://www.icy-veins.com/feed.atom" type="application/atom+xml" rel="alternate" title="Icy Veins - Feed" />',
    '<script type="text/javascript" src="http://static.icy-veins.com/javascript/icyveins-common-63f86a417c4150f6daa9660b116a5650.js"></script>',
]
def redohtml(url):
    # 
    name = os.path.split(url)[1]
    folder = os.path.join(HERE, BUILDS)
    if not os.path.lexists(folder):# deleted the folder?
        os.mkdir(folder) # make a new one then
    path = os.path.join(folder, name + '.html')
    if not os.path.lexists(path): # deleted the files? if so redownload otherwise do nothing
        f = urllib.urlopen(url)
        pg = f.read()
        te = '</script>'
        to = '</div>'
        while True:
            scr = pg.find('<script type="text/javascript">')
            cra = pg.find('<div class="page_breadcrumbs text_color">')
            hry = pg.find('<div class="centered">')
            if scr > -1:
                end = pg.find(te, scr)
                pg = pg[:scr] + pg[end+len(te):]
            elif cra > -1:
                end = pg.find(to, cra)
                pg = pg[:cra] + pg[end+len(to):]
            elif hry > -1:
                end = pg.find(to, hry)
                tmp = pg[:hry] + pg[end+len(to):]
                if pg[hry:end].find('iframe') > -1:
                    pg = tmp
                break
            else:
                break
        pg = pg.replace("'s ", 's ', -1)
        for crap in BULL:
            pg = pg.replace(crap, '')
        with open(path, 'w') as f:
            f.write(pg)
    return path
import shutil
def removebuilds():
    folder = os.path.join(HERE, BUILDS)
    if os.path.lexists(folder):# deleted the folder?
        shutil.rmtree(folder)

    
CLASSES = "Barbarian, Crusader, Demon Hunter, Monk, Witch Doctor, Wizard".split(', ')
# color of classes
BARB = '#ff7f00' # orange
CRUS = '#eae0c8' # pearl
DHER = '#8b0000' # dark red
MONK = '#ffd500' # mostly pure yellow
WDOC = '#00008b' # dark blue
WIZD = '#600080' # dark megenta
CCOLORS = [BARB, CRUS, DHER, MONK, WDOC, WIZD]
# color of items
CSET = '#8bd442' # a green
CLEG = '#bf642f' # a orange
# def classcolor(cls):    done = None    for c, h in zip(CLASSES, CCOLORS):        if cls == c:            done = h            break    return done



        
        
def startused(line, index):
##  <li><a href="http://www.icy-veins.com/d3/demon-hunter-speedrun-multishot-fire-build-with-yangs-recurve-patch-2-4">Multishot Speedfarm Demon Hunter</a> (BiS)</li>
    i = index
    if line == '<ul>':
        i += 1
    href = line.find('a href=')
    if href == -1:
        return None, None, i
    else:
        href = line[href+8:]
        href, text = href.split('">', 1)
        text = text.replace('</a>', '').replace('</li>', '')
        return href, text, i


def FromCheckBoxStrings(klasses):
    donot = [False, False, False, False, False, False] # class (BARB, CRUS, DHER, MONK, WDOC, WIZD)
    sets = False
    #, False, False]
    for i, cls in enumerate(CLASSES):
        if cls in klasses:
            donot[i] = True
    if 'Show Sets' in klasses:
        sets = True
    if 'Show All' in klasses:
        sets = None
    t = tuple(donot)
    return (t[0], t[1], t[2], t[3], t[4], t[5], sets)
    # only:
        #   barb, crus, dher, monk, wdoc, wizd, sets
def isvis(item, sets, yup):
    y = yup
    if sets is not None:
        if sets and not item.islegendary():
            y = True
        if not sets and item.islegendary():
            y = True
    else:
        y = True
    return y
def Populate(klasses, items):
    ls = []
    barb, crus, dher, monk, wdoc, wizd, sets = FromCheckBoxStrings(klasses)
    
    for item in items:
        yup = False
        if barb:
            if item.isclass(CLASSES[0]): 
                yup = isvis(item, sets, yup)
        if crus:
            if item.isclass(CLASSES[1]): 
                yup = isvis(item, sets, yup)
        if dher:
            if item.isclass(CLASSES[2]): 
                yup = isvis(item, sets, yup)
        if monk:
            if item.isclass(CLASSES[3]): 
                yup = isvis(item, sets, yup)
        if wdoc:
            if item.isclass(CLASSES[4]): 
                yup = isvis(item, sets, yup)
        if wizd:
            if item.isclass(CLASSES[5]): 
                yup = isvis(item, sets, yup)
        if yup:
            ls += [item]
    return ls
def titlefile(title):
    done = None
    for c, h in zip(CLASSES, "BARB, CRUS, DHER, MONK, WDOC, WIZD".lower().split(', ')):
        if title.find(c) > -1:
            done = os.path.join(HERE, h + '.png')
            break
    return done

def itembuilds(item): # the returned list may have (None, []) as an item
    done = []
    BARB, CRUS, DHER, MONK, WDOC, WIZD = ([], [], [], [], [], [])
    barb, crus, dher, monk, wdoc, wizd = (None, None, None, None, None, None)
    for build in item.builds:
        png = titlefile(build.title)
        cls, name = build.split()
        if cls == CLASSES[0]:
            barb = png
            BARB += [str(build)]
        if cls == CLASSES[1]:
            crus = png
            CRUS += [str(build)]
        if cls == CLASSES[2]:
            dher = png
            DHER += [str(build)]
        if cls == CLASSES[3]:
            monk = png
            MONK += [str(build)]
        if cls == CLASSES[4]:
            wdoc = png
            WDOC += [str(build)]
        if cls == CLASSES[5]:
            wizd = png
            WIZD += [str(build)]
    #print len(BARB), len(CRUS), len(DHER), len(MONK), len(WDOC), len(WIZD), '=', 
    tmp = [BARB, CRUS, DHER, MONK, WDOC, WIZD]
    for png in [barb, crus, dher, monk, wdoc, wizd]:
        done += [(png, tmp.pop(0))]
    return done
def itemcolor(item):
    fgcolor = CSET
    if item.islegendary():
        fgcolor = CLEG
    return fgcolor


htmltemplate = lambda data: """\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html
     PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
     "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
    <title>Diablo 3 Legendary Item Salvage Guide - Icy Veins</title>
    <script type="text/javascript" async="async" src="http://us.battle.net/d3/static/js/tooltips.js"></script>
    <style>
    .d3_legendary {{
        color: {};
    }}
    .d3_set {{
        color: {};
    }}
    body {{
        background-color: black;
        color: white;
    }}
</style>
</head>
<body>
{}
</body>
</html>
""".format(CLEG, CSET, data)
TABLE = '<table><tbody><tr><th>Image</th><th>Name</th><th>Builds the item is used in</th></tr>'

htmltemplateimg = lambda src, cls, tip: '<img src="{}" alt="{}" title="{}"/>'.format(src, cls, tip)
htmltemplatea = lambda cls, ref, desc: '<a rel="nofollow" class="{}" href="{}">{}</a>'.format(cls, ref, desc)
def mkhtml(items):
    done = []
    for item in items:
        fgcolor = itemcolor(item)
        pngs = itembuilds(item) # (png, ls)
        his = []
        for png, ls in pngs:
            if png is not None:
                s = '\n'.join(ls)
                hi = htmltemplateimg(png, s, s)
                his += [hi]
        his = '\n'.join(his)
        a = htmltemplatea(item.cls, item.ref, item.alt)
        img = htmltemplateimg(item.src, item.alt, item.ref)
        li = '<tr><td>' + img + '</td><td>' + a + '</td><td>' + his + '</td></tr>'
        done += [li]
    done = htmltemplate(TABLE + '\n'.join(done) + '</tbody></table>')
    path = os.path.join(HERE, 'tmp.html')
    with open(path, 'w') as f:
        f.write(done)
    return path, done

# this is exclusively for "def fire"
def passit(lines, last=False): # used to make 2 lists
    # pass 1 for column 1 (items), the 2nd pass for column 2 (builds)
    done = []
    for line in lines:
        mark = False
        if line in ['<ul>', '</ul>']:
            mark = True
        elif line.startswith('<li>'):
            mark = True
        if mark:
            if last:
                done += [line]
                # last pass is gathering the <ul>
        else:
            if not last:
                done += [line]
                # non last pass is what is not <ul>
    return done # last pass does not goto feed of htmlparse, only the first pass

def fire(f):
    parser = MyHTMLParser()
    builds = {}
    index = -1
    with open(f) as ff:
        data = ff.read()
        fnd = data.find('<table class="salvage_table">')
        if fnd > -1:
            to = '</tbody></table>'
            end = data.find(to, fnd)
            data = data[fnd:end+len(to)]
        data = data.splitlines(0)
        lines = passit(data)
        parser.feed('\n'.join(lines))
        lines = passit(data, True)
        for line in lines:
            href, text, index = startused(line, index)
            if None not in [href, text]:
                if index not in builds:
                    builds[index] = [Build(href, text)]
                else:
                    #if Build(href, text) not in builds[index]:
                    builds[index].append(Build(href, text))
    sz = len(parser.items)
    for i in builds:
        ls = builds[i]
        if i < sz:
            for t in ls:
                parser.items[i].builds.append(t)
    return parser.items
    
# items = fire(r"D:\dev\py\work\d3items\Diablo 3 Legendary Item Salvage Guide - Icy Veins.htm")
            
def uniquebuilds(items):
    builds = {}
    for item in items:
        # item.alt, item.src, item.cls, 
        for b in item.builds:
            cls, name = b.split()
            name = b.linkname()
            if cls is not None:
                if cls not in builds:
                    builds[cls] = [(name, b.link)]
                else:
                    if (name, b.link) not in builds[cls]:
                        builds[cls].append((name, b.link))
            else:
                builds[cls] = [(name, b.link)]
#    print '\n'.join(builds)
    return builds

    
"""

python d3itemshtml.py > d3items.txt

for item in items:
    print item ## item.alt, item.src, item.cls, item.builds
getting unique build names
"""
