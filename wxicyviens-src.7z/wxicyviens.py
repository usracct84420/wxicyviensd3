## Copyright (c) 2016, Joshua Dagenhart
## All rights reserved.
## 
## Redistribution and use in source and binary forms, with or without
## modification, are permitted provided that the following conditions are met:
## 
## 1. Redistributions of source code must retain the above copyright notice, this
##    list of conditions and the following disclaimer.
## 2. Redistributions in binary form must reproduce the above copyright notice,
##    this list of conditions and the following disclaimer in the documentation
##    and/or other materials provided with the distribution.
## 
## THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
## ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
## WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
## DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
## ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
## (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
## LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
## ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
## (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
## 
## The views and conclusions contained in the software and documentation are those
## of the authors and should not be interpreted as representing official policies,
## either expressed or implied, of the FreeBSD Project.
import  wx
import d3itemshtml # CLASSES, Populate, mkhtml, fire, uniquebuilds, redohtml
import wx_ie_d3 # URLPagePanel
class OnlyChecks(wx.Panel):
    def __init__(self, parent):
        wx.Panel.__init__(self, parent, -1, style=wx.WANTS_CHARS)
        sizer = wx.BoxSizer()
        self.ls = []
        for cls in d3itemshtml.CLASSES:
            chk = wx.CheckBox(self, -1, cls)
            self.ls += [chk]
            sizer.Add(chk, 0, wx.ALL, 1)
        self.only = wx.CheckBox(self, -1, 'Show Legendary', style=wx.CHK_3STATE|wx.CHK_ALLOW_3RD_STATE_FOR_USER)
        sizer.Add(self.only, 0, wx.ALL, 1)
        self.only.Bind(wx.EVT_CHECKBOX, self.OnB)
        self.SetSizer(sizer)
    def GetKls(self):
        ls = []
        for chk in self.ls:
            if chk.GetValue():
                ls += [chk.GetLabel()]
        ls += [self.only.GetLabel()]
        return ls
    def OnB(self, evt):
        if evt.GetId() == self.only.GetId():
            sel = self.only.Get3StateValue()
            if sel == 1:
                self.only.SetLabel('Show All')
            elif sel == 0:
                self.only.SetLabel('Show Legendary')
            else:
                self.only.SetLabel('Show Sets')
            self.Layout()
        evt.Skip()
class HtmlPanel(wx.Panel):
    def __init__(self, parent, items):
        wx.Panel.__init__(self, parent, -1, style=wx.WANTS_CHARS)
        self.items = items
        self.only = OnlyChecks(self)
        self.ie = wx_ie_d3.URLPagePanel(self)
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.only, 0, wx.ALL, 5)
        sizer.Add(self.ie, 1, wx.ALL|wx.EXPAND, 5)
        self.SetSizer(sizer)
        for chk in self.only.ls + [self.only.only]:
            self.only.Bind(wx.EVT_CHECKBOX, self.OnB, chk)
        tmp = d3itemshtml.Populate(['Show Legendary'], self.items)
        path, done = d3itemshtml.mkhtml(tmp)
        self.ie.ie.LoadUrl(path)
       
    def OnB(self, evt):
        klasses = self.only.GetKls()
        items = d3itemshtml.Populate(klasses, self.items)
        path, done = d3itemshtml.mkhtml(items)
        self.ie.ie.LoadUrl(path)
        evt.Skip()
UPDATE = []
TEXT = "After it is done it isn't as IE will hang"
FIRE = r"D:\dev\py\work\d3items\Diablo 3 Legendary Item Salvage Guide - Icy Veins.htm"
LIC = """\
Copyright (c) 2016, Joshua Dagenhart
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of the FreeBSD Project.
"""
from wx.lib.wordwrap import wordwrap

class ListFrame(wx.Frame):
    def __init__(self, parent, title, size):

        wx.Frame.__init__(self, parent, -1, title, pos=wx.DefaultPosition, size=size, style=wx.DEFAULT_FRAME_STYLE)
        self.CreateStatusBar()

        self.Populate()
        self.Bind(wx.EVT_CLOSE, self.OnCloseWindow, self)
        self.CenterOnScreen(True)
        self.Show(True)
    def Populate(self):
        self.items = d3itemshtml.fire(FIRE)
        self.tp = HtmlPanel(self, self.items)
        #self.tp = ListPanel(self, items)
        sizer = wx.BoxSizer(wx.VERTICAL)
        #sizer.Add(self.tp, 1, wx.ALL|wx.EXPAND, 5)
        #sizer.Add(self.ie, 1, wx.ALL|wx.EXPAND, 5)
        sizer.Add(self.tp, 1, wx.ALL|wx.EXPAND, 5)
        self.SetSizer(sizer)
        # Prepare the menu bar
        menuBar = wx.MenuBar()

        # 1st menu from left
        builds = d3itemshtml.uniquebuilds(self.items)
        self.ids = {}
        last = -1
        start = 100
        for cls in builds:
            menu = wx.Menu()
            for i, bc in enumerate(builds[cls]):
                title, href = bc
                Id = start + (i + 1)
                last = Id
                menu.Append(Id, title, href)
                self.ids[Id] = href
            if cls is not None:
                menuBar.Append(menu, cls)
            else:
                menuBar.Append(menu, "Misc")
            start += 100
        cnt = menuBar.GetMenuCount()
        menu = menuBar.GetMenu(cnt-1)
        menu.Append(last+1, "Update Builds", "Rebuild cache of webpages for builds")
        menu.Append(last+2, "About", "What? When? Where? Who?")
        UPDATE.append(last+1)
        self.SetMenuBar(menuBar)
        self.Bind(wx.EVT_MENU_RANGE, self.OnMenu, id=101, id2=last+1)
        self.Bind(wx.EVT_MENU, self.OnAbout, id=last+2)
        self.Layout()
    def OnAbout(self, evt):
        info = wx.AboutDialogInfo()
        info.Name = "wxIcyViens"
        info.Version = "1.3.6.9"
        info.Copyright = "(C) 2016 Joshua Dagenhart (nane#11477)"
        text = "Built with Anaconda Python 2.7.11 and py2exe 0.6.9 on Win7 Ultimate (SP1) using wxPython 3.0.2.0 by August starting around mid-July of 2016\n\n" + \
'When "Diablo 3 Legendary Item Salvage Guide - Icy Veins.htm" becomes outdated, just re-download using default name and Web-Page Complete setting and replace both the folder and the file.' + \
' When that happens, start the application and select "Update Builds" from the "Misc" menu on the menubar as this will then populate the menu and the "All Builds" folder based on the newly replaced webpage downloaded.' + \
' Intended use is check a class\'s checkbox and the concise listing should aid in salvage choices or select a class\'s build from the menu to view build information.' + \
"""\n
Many thanks to icyviens.com for making this possible! Of course I thank the beings behind the software of python, py2exe, and wxpython!
"""
        info.Description = wordwrap(text, 350, wx.ClientDC(self))
        info.WebSite = ("http://www.icy-veins.com/d3", "Icy Viens Diablo 3 home page")
        info.Developers = [ "Joshua Dagenhart"]

        info.License = wordwrap(LIC, 500, wx.ClientDC(self))

        # Then we call wx.AboutBox giving it that info object
        wx.AboutBox(info)
        

    def OnMenu(self, evt):
        Id = evt.GetId()
        if Id in UPDATE:
            dlg = self.progress(len(self.ids))
            d3itemshtml.removebuilds()
            self.Populate()
            keepGoing = True
            cnt = 0
            for inid in self.ids:
                text = TEXT + '\n{}'.format(self.GetMenuBar().FindItemById(inid).GetLabel())
                (keepGoing, skip) = dlg.Update(cnt, text)
                if keepGoing:
                    path = d3itemshtml.redohtml(self.ids[inid])
                    self.tp.ie.ie.LoadUrl(path)
                else:
                    break
                cnt += 1
                (keepGoing, skip) = dlg.Update(cnt, text)
            dlg.Destroy()
        else:
            path = d3itemshtml.redohtml(self.ids[Id])
            self.tp.ie.ie.LoadUrl(path)
        
    def OnCloseWindow(self, evt):
        self.Destroy()
        evt.Skip()
        max = 80
    def progress(self, maximum):
        dlg = wx.ProgressDialog("Retrieving build pages...",
                               TEXT,
                               maximum = maximum,
                               parent=self,
                               style = 0
                                | wx.PD_APP_MODAL
                                | wx.PD_CAN_ABORT
                                #| wx.PD_CAN_SKIP
                                #| wx.PD_ELAPSED_TIME
                                | wx.PD_ESTIMATED_TIME
                                | wx.PD_REMAINING_TIME
                                | wx.PD_AUTO_HIDE
                                )
        return dlg

                


class MyApp(wx.App):
    def OnInit(self):
        f = ListFrame(None, "Launcher", (800, 800))
        self.SetTopWindow(f)
        return True
        
    
REDIRECT, OUT = (False, 'errors.txt')
def runapp():
    app = MyApp(useBestVisual=True) if not REDIRECT else MyApp(REDIRECT, OUT, True)
    return app
    
if __name__ == '__main__':
    app = runapp()
    app.MainLoop()
    
